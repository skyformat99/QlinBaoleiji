#ifndef SSH_DISPLAY_H
#define SSH_DISPLAY_H

extern int monitor_mode;
extern int monitor_arg1;
extern int monitor_arg2;

int is_monitor_account( char *str, char **radius, int *arg1, int *arg2 )

#endif
